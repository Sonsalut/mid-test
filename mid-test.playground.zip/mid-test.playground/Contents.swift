import Cocoa

//Tạo 1 Dictionary từ 2 mảng
var keys = ["key1", "key2", "key3", "key4"]
var values = ["value1", "value2", "value3"]

var myDictionary = [String: String]()

let m = keys.count
let n = values.count

if m > n {
    for _ in 1...m-n {
        values.append("value_")
    }
}
if m < n {
    for _ in 1...n-m {
        keys.append("key_")
    }
}

myDictionary = Dictionary(uniqueKeysWithValues: zip(keys, values))
print(myDictionary)

//kiểm tra tổng N là chẵn hay lẻ

func kiemTraTong(n: Int) {
    if n % 2 == 0 {
        n % 4 == 0 ? print("tổng các số từ 1 đến n là chẵn") : print("tổng các số từ 1 đến n là lẻ")
    } else {
        n-1 % 4 == 0 ? print("tổng các số từ 1 đến n là lẻ") : print("tổng các số từ 1 đến n là chẵn")
    }
}

kiemTraTong(n: 3)

//cộng 1 mảng số nguyên và 1 mảng số thập phân thành mảng mới, sắp xếp



